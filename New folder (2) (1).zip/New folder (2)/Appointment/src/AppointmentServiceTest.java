import static org.junit.jupiter.api.Assertions.*;
import org.junit.Before;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
	private AppointmentService appointmentService;
	@Before
	public void setUp() {
		appointmentService =  new AppointmentService();
	}
	@Test
	public void testAddAppointment() {
		Date appointmentDate = new Date();
		Appointment appointment = new Appointment("12145", appointmentDate, "Test Description");
		appointmentService.addAppointment(appointment);
		assertNotNull(appointmentService.getAppointments().get("12145"));
	}
	public void testDeleteAppointment() {
        Date appointmentDate = new Date();
        Appointment appointment = new Appointment("12145", appointmentDate, "Test Description");
        
        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("12145");
        
        assertNull(appointmentService.getAppointments().get("12145"));
	
	}

}
