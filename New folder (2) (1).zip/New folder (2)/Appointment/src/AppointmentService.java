import java.util.HashMap;
import java.util.Map;
public class AppointmentService {
	private final Map<String, Appointment> appointments;

	public AppointmentService() {
		// TODO Auto-generated constructor stub
		appointments = new HashMap<>();
	
	}

	public void addAppointment(Appointment appointment) {
		// TODO Auto-generated method stub
		appointments.put(appointment.getAppointmentId(), appointment);
	}
	public void deleteAppointment(String appointmentId) {
		appointments.remove(appointmentId);

	}

}
