import static org.junit.Assert.assertEquals;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentTest {

	@Test
	public void testGetters() {
		Date appointmentDate = new Date();
		Appointment appointment = new Appointment("12145", appointmentDate, "Test Description");
		assertEquals("12145", appointment.getAppointmentId());
		assertEquals(appointmentDate, appointment.getAppointmentDate());
		assertEquals("Test Description", appointment.getDescription());
	}

}
