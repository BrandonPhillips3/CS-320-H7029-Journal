import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.Assert;
import org.junit.Before;
public class TaskTest {

	@Test
	public void test() {
		Task task = new Task("0000000001", "Walking", "Walk Dog down street");
			System.out.println(task);
	}

}
