import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class TaskService {
		// TODO Auto-generated constructor stub
	public static List<Task> tasks =  new ArrayList<>();

	public static void main(String[] args) {
		TaskService service = new TaskService();
		 service.addTask(new Task("0000000001", "Reading", "Read Novel Book"));
	     service.addTask(new Task("0000000002", "Playing", "Playstation 5"));
	     service.addTask(new Task("0000000003", "Walking", "Walk the dog"));
	    for (Task obj : tasks) {
	    	System.out.print(obj);
	    }
	
service.addTask(new Task("0000000001", "Singing", "Wedding Engagement"));
System.out.println("Delete Task ID #0000000002");
	service.deleteTask("0000000002");
	 System.out.println("Update Task ID #0000000003");
     service.update(new Task("0000000003", "Running", "Jogging with friends"));
for (Task obj : tasks) {
	System.out.println(obj);
}
	}
private void update(Task task) {
		// TODO Auto-generated method stub
		for(Task obj : tasks) {
			if(obj.equals(task) && validateName(task.getName()) && validateDescription(task.getDescription())){
				obj.setName(task.getName());
				obj.setDescription(task.getDescription());
			}
		}
	}
public boolean addTask(Task task) {
		// TODO Auto-generated method stub
		int index = getindex(task);
		if (index < 0 && validateID(task.getId())&& validateName(task.getName()) && validateDescription(task.getDescription())) {
            tasks.add(task);
            return true;
	}
		return false;
}
	private void deleteTask(String id) {
		// TODO Auto-generated method stub
		int index = getindex(new Task(id, "", ""));
			if (index >= 0)
				Task.remove(index);
}

		public boolean validateDescription(String description) {
		// TODO Auto-generated method stub
			if (description != null && description.length() <= 50)
				return true;
			
		return false;
	}

		public boolean validateName(String name) {
		// TODO Auto-generated method stub
			if (name != null && name.length() <= 20)
				return true;
			
		return false;
	}

		private boolean validateID(String id) {
		// TODO Auto-generated method stub
			if (id != null && id.length() <= 10)
				return true;
			
		return false;
	}

		public int getindex(Task task) {
			// TODO Auto-generated method stub
			int index = Collections.binarySearch(tasks, task, Task.compareById);
			return index;
		}
	}
