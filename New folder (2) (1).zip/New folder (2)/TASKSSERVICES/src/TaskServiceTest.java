import static org.junit.jupiter.api.Assertions.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TaskServiceTest {
	public static List<Task> tasks = new ArrayList<>();
	@Test
	public void validTaskData() {
		Task task = new Task("0000000001", "Walking", "walk dog down street");
			addTask(task);
			System.out.print("New Task:" + tasks);
			System.out.print("size:" + tasks.size());
	}
	

	public void invalidID() {      
	      Task task = new Task("0000000002x", "Playing", "Playstation 5");
	      addTask(task);
	      System.out.println("size: " + tasks.size());
	   }
	   
	public void invalidName() {      
	      Task task = new Task("0000000002", "Playing Playing Playing Playing Playing Playing Playing", "Playstation 5");
	      addTask(task);
	      System.out.println("size: " + tasks.size());
	   }
	   
	public void invalidDescription() {      
	      Task task = new Task("0000000002", "Playing", "Playstation 5 Playstation 5 Playstation 5 Playstation 5 Playstation 5 Playstation 5");
	      addTask(task);

	}
	public void existingID() {      
	      Task task = new Task("0000000001", "Reading", "Read Novel Book");
	      addTask(task);
	      System.out.println("size: " + tasks.size());
	   }
	public void updateTask() {
		 Task task = new Task("0000000001", "Singing", "Wedding Engagement");
	      update(task);
	      System.out.println("Updated: " + tasks);
	      System.out.println("size: " + tasks.size());
	}
	public void update(Task task) {
		// TODO Auto-generated method stub
		 for (Task obj : tasks) {
	            if (obj.equals(task) && validateName(task.getName()) && validateDescription(task.getDescription())) {
	                obj.setName(task.getName());
	                obj.setDescription(task.getDescription());
	            }
		 }
	}
	public boolean addTask(Task task) {
		int index = getIndex(task);
		if (index < 0 && validateID(task.getId()) && validateName(task.getName()) && validateDescription(task.getDescription())) {
            tasks.add(task);
            return true;
		}
		return false;
	}
	

	public boolean validateID(String id) {
		// TODO Auto-generated method stub
	        if (id != null && id.length() <= 10)
	            return true;

	        return false;
	    }

public void deleteTask(String id) {
	int index = getIndex(new Task(id, "",""));
	if(index >= 0)
		tasks.remove(index);
}
	public int getIndex(Task task) {
		// TODO Auto-generated method stub
		int index = Collections.binarySearch(tasks, task, Task.compareById);
        return index;
	}
	public boolean validateDescription(String description) {
		// TODO Auto-generated method stub
			if (description != null && description.length() <= 50)
				return true;
			
		return false;
	}
	public boolean validateName(String name) {
		// TODO Auto-generated method stub
			if (name != null && name.length() <= 20)
				return true;
			
		return false;
	}

}